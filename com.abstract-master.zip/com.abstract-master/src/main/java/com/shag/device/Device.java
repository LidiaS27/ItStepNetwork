package com.shag.device;

public interface Device {

    boolean request();

    boolean response();

}
